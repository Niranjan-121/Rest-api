package com.example.demo.Dao;
import com.example.demo.Model.Person;


import java.util.List;
import java.util.Optional;
import java.util.UUID;
public interface PersonDao {

    public int insertPerson(UUID id, Person person);

    default int insertPerson(Person person) {
        UUID id=UUID.randomUUID();
        return insertPerson(id ,person);
    }
     List<Person> selectAllPeople();
    Optional<Person> selectPersonByid(UUID id);


    int DeletePersonByUUID(UUID id);

    int UpdatePersonByUUID(UUID id, Person person);
}
