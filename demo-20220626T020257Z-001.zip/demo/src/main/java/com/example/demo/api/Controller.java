package com.example.demo.api;

import com.example.demo.Model.Person;
import com.example.demo.Service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RequestMapping("api/person")
@RestController
public class Controller {

    private final PersonService personService;
    @Autowired
    public Controller(PersonService personService) {
        this.personService = personService;
    }
    @PostMapping
    public void addPerson(@Valid @NonNull @RequestBody Person person){
        personService.addPerson(person);
    }
    @GetMapping
    public List<Person> getAllPeople(){
        return personService.getAllPeople();
    }

    @GetMapping(path = "{id}")
    public Person getPersonByid(@PathVariable("id") UUID id){
        return personService.getPersonByid(id)
                .orElse(null);
    }
    @DeleteMapping(path="{id}")
    public void DeletePersonBYUUId(@PathVariable("id") UUID id){
         personService.DeletePersonByUUID(id);
    }
    @PutMapping(path = "{id}")
    public void UpdatePersonByUUID(@PathVariable("id") UUID id,@Valid @NonNull @RequestBody Person PersonToUpdate){
        personService.UpdatePersonByUUID(id,PersonToUpdate);
    }

}
