package com.example.demo.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotBlank;
import java.util.UUID;

public class Person {
    @NotBlank
    private final UUID id;
    @NotBlank
    private final String name;
    @NotBlank
    private final String email;
    @NotBlank
    private final String pass;

    public Person(@JsonProperty("id") UUID id,
                  @JsonProperty("name") String name,
                  @JsonProperty("email") String email,
                  @JsonProperty("pass") String pass) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.pass = pass;
    }
    public UUID getId(){
        return id;
    }

    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }
    public String getPass(){
        return pass;
    }





}
