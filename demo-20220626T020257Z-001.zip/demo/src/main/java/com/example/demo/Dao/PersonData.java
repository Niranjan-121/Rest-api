package com.example.demo.Dao;

import com.example.demo.Model.Person;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository("dao")
public class PersonData implements PersonDao{

    private static List<Person> DB=new ArrayList<>();

    @Override
    public int insertPerson(UUID id, Person person) {
        DB.add(new Person(id, person.getName(), person.getEmail(), person.getPass()));
        return 1;
}

    @Override
    public List<Person> selectAllPeople() {
        return DB;
    }

    @Override
    public Optional<Person> selectPersonByid(UUID id) {
        return DB.stream()
                .filter(person -> person.getId().equals(id))
                .findFirst();
    }

    @Override
    public int DeletePersonByUUID(UUID id) {
        Optional<Person> personDel=selectPersonByid(id);
        if(personDel.isEmpty()){
            return 0;
        }
        else{
            DB.remove(personDel.get());
            return 1;
        }
    }

    @Override
    public int UpdatePersonByUUID(UUID id, Person update) {
        return selectPersonByid(id)
                .map(person ->{
                    int IndexofPerson = DB.indexOf(person);
                    if(IndexofPerson>=0){
                        DB.set(IndexofPerson,new Person(id,update.getName(),update.getEmail(), update.getPass()));
                        return 1;
                    }
                    return 0;
                })
                .orElse(0);
    }


}
